package techpal.models;

public class Period {
    private String per;

    public Period() {
    }

    public String getPer() {
        return per;
    }

    public void setPer(String per) {
        this.per = per;
    }

}
