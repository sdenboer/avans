package techpal.models;

public class Program {
    private String progNm;

    public Program() {
    }

    public String getProgNm() {
        return progNm;
    }

    public void setProgNm(String progNm) {
        this.progNm = progNm;
    }
}
