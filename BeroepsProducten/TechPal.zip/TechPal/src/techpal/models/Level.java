package techpal.models;

public class Level {
    private String lvl;

    public Level() {
    }

    public String getLvl() {
        return lvl;
    }

    public void setLvl(String lvl) {
        this.lvl = lvl;
    }
}
