package techpal.models;

public class Device {
    private String tstl;

    public Device() {
    }

    public String getTstl() {
        return tstl;
    }

    public void setTstl(String tstl) {
        this.tstl = tstl;
    }
}