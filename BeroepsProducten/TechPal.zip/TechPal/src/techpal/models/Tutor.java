package techpal.models;

public class Tutor extends Person {

    public Tutor() {
    }
}
