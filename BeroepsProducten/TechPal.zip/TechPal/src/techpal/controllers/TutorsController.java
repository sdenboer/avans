package techpal.controllers;

import techpal.models.Tutor;

public class TutorsController {

    public TutorsController() {
    }

    public static Tutor currentTutor = new Tutor();

}
