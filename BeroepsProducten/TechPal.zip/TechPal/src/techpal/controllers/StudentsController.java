package techpal.controllers;

import techpal.models.Student;

public class StudentsController {

    public StudentsController() {
    }

    public static Student currentStudent = new Student();

}
